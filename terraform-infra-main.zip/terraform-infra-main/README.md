# terraform-infra
Terraform module for azure infrastructure creation
